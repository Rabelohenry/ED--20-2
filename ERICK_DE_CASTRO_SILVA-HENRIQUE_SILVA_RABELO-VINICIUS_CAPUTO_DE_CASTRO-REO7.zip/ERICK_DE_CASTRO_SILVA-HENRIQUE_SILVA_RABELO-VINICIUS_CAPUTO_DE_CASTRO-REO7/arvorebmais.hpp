#include <iostream>
#include <fstream>
#include <stdexcept>
#include "sequenceset.hpp"
#include "pagina.hpp"

using namespace std;

class arvorebmais{
    private:
        sequenceset* meuSeqSet;
        pagina* raiz;
        int posDentroPagina(pagina* atual,tipoChave chave);
        void percorrePosOrdem(pagina* atual);
        void insereAux(pagina*atual,dado umDado);
        void dividirPagina(pagina* atual);
        dado buscaAux(pagina* atual,tipoChave chave);
        void inserirArquivo();
        void insereAux(pagina* atual, promocao mPromocao);
    public:
        arvorebmais();        
        void inserirDado(dado umDado);
        void imprimir();
        dado buscar(tipoChave chave);
};


arvorebmais::arvorebmais() {
    meuSeqSet = new sequenceset("teste.dat");
    raiz = new pagina;
    raiz->folha = true;
    if (meuSeqSet->numPacotes > 0){
       // inserirArquivo();
    }
}
//
void arvorebmais::imprimir(){
    percorrePosOrdem(raiz);
    meuSeqSet->imprimir();
}
void arvorebmais::inserirArquivo(){
    pacote* atual = new pacote;
    meuSeqSet->lerPacoteDoArquivo(atual,meuSeqSet->posPrimeiroPacote);
    meuSeqSet->lerPacoteDoArquivo( atual,atual->posProximoPacote);
    while(atual->posProximoPacote != -1){
        promocao mPromocao = meuSeqSet->percorrePacotes(atual->posProximoPacote);
        insereAux(raiz,mPromocao);
    }
    
}
void arvorebmais::percorrePosOrdem(pagina* atual){
    if( atual != NULL){
        atual->imprimir();
        for (int i = 0; i < atual->numElementos; i++){
            percorrePosOrdem(atual->filho[i]);
        }
    }
}
//
int arvorebmais::posDentroPagina(pagina* atual, tipoChave chave ){
    int posicao = atual->numElementos - 1;
    while ( (posicao >= 0) and chave < atual->chave[posicao]) {
        posicao--;
    }
    return posicao;
}

void arvorebmais::inserirDado(dado umDado){
    if (meuSeqSet->numPacotes == 0){
        meuSeqSet->inserirDado(umDado);
        raiz->posArquivo[0]= meuSeqSet->posPrimeiroPacote;
    }
    else{
        insereAux(raiz,umDado);    
    }
}
void arvorebmais::insereAux(pagina* atual, dado umDado){
    //atual->depurar();
    promocao mPromocao;
    int posicao = posDentroPagina(atual, umDado.chave);
    if (atual->folha){
        mPromocao = meuSeqSet->inserirDado(umDado,atual->posArquivo[posicao+1]);
        if (mPromocao.ocorreu){
            atual->inserir(mPromocao.promovido, mPromocao.posicaoArquivo);
        }
    } else {
        insereAux(atual->filho[posicao+1], umDado);
    }
    if (atual->paginaCheia()){
       // cout << "entrou na pagina cheia " << endl;
        dividirPagina(atual);
    }
}

void arvorebmais::insereAux(pagina* atual ,promocao mPromocao){
    int posicao = posDentroPagina(atual, mPromocao.promovido);
    if (atual->folha){
        if (mPromocao.ocorreu){
            atual->inserir(mPromocao.promovido, mPromocao.posicaoArquivo);;
        }
    } else {
        insereAux(atual->filho[posicao+1], mPromocao);
    }
    if (atual->paginaCheia()){
        //cout << "entrou na pagina cheia " << endl;
        dividirPagina(atual);
    }
}

void arvorebmais::dividirPagina(pagina* atual){
    if (atual->pai == NULL){
        pagina* novoPai = new pagina;
        novoPai->filho[0] = atual;
        novoPai->folha = false;
        atual->pai = novoPai;
    }
    pagina* irmao = new pagina;
    irmao->pai= atual->pai;
    if (not(atual->folha)){
        irmao->folha = false;
    }
    for (int i = 0; i < meioPagina; i++){
        irmao->chave[i] = atual->chave[i+meioPagina+1];
        irmao->posArquivo[i+1] = atual->posArquivo[i+meioPagina+2];
        irmao->filho[i+1] = atual->filho[i+meioPagina+2];
    }
    irmao->filho[0]= atual->filho[meioPagina+1];
    irmao->posArquivo[0]= atual->posArquivo[meioPagina+1];
    atual->numElementos = meioPagina;
    irmao->numElementos = meioPagina;
    atual->pai->inserir(atual->chave[meioPagina], irmao);
    if (atual == raiz){
        raiz = atual->pai;
    }
}

dado arvorebmais::buscar(tipoChave chave){
    return buscaAux(raiz,chave);
}

dado arvorebmais::buscaAux(pagina* atual, tipoChave chave){
    int posicao = posDentroPagina(atual, chave);
    if (atual->folha){
        return meuSeqSet->buscar(chave,atual->posArquivo[posicao+1]);
    }else{
        return buscaAux(atual->filho[posicao+1],chave);
    }
}