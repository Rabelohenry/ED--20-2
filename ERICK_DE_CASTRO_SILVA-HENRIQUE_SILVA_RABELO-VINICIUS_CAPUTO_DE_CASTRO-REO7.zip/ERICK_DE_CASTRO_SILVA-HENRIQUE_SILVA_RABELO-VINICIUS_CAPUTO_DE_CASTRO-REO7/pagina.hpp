#include <iostream>

using namespace std;

const int capacidade = 9;
const int meioPagina = 4;

class pagina{
    friend class arvorebmais;
    private:
        bool folha;
        unsigned numElementos;
        tipoChave chave[capacidade+1];
        int posArquivo[capacidade+2];
        pagina* filho[capacidade+2];
        pagina* pai;
    public:
        pagina();
        void inserir(tipoChave promovido, int posRecebida);
        void inserir(tipoChave promovido, pagina* filho);
        void imprimir();
        void depurar();
        bool paginaCheia(){ return (numElementos > capacidade );}
        ~pagina();
};

pagina::pagina(){
    folha = true;
    numElementos= 0;
    pai = NULL;
    for (int i = 0; i < capacidade+1; i++){
        filho[i] = NULL;
        posArquivo[i] = -1;
    }
    posArquivo[capacidade+1] = -1;
}

void pagina::inserir(tipoChave promovido, int posRecebida){
    int posicao = numElementos -1 ;
    cout << chave[posicao+1] << endl;
    while ( (posicao >= 0) and promovido < chave[posicao]) {
        chave[posicao+1] = chave[posicao];
        filho[posicao+2] = filho[posicao+1];
        posArquivo[posicao+2] = posArquivo[posicao+1];
        //cout<< "posicaoArquivo+1: " << posArquivo[+2] << " posArquivo: " << posArquivo[posicao]<< endl; 
        posicao--;
    } 
    //cout << "posicaoPAgina: " << posicao+1 << endl;
    chave[posicao+1] = promovido;
    posArquivo[posicao+2]= posRecebida;
    numElementos++;
}

void pagina::inserir(tipoChave promovido, pagina* Mfilho){
    int posicao = numElementos -1 ;
    while ( (posicao >= 0) and promovido < chave[posicao]) {
        chave[posicao+1] = chave[posicao];
        filho[posicao+2] = filho[posicao+1];
        posArquivo[posicao+2] = posArquivo[posicao+1];
        //cout<< "posicaoArquivo+1: " << posArquivo[+2] << " posArquivo: " << posArquivo[posicao]<< endl; 
        posicao--;
    } 
    //cout << "posicaoPAgina: " << posicao+1 << endl;
    chave[posicao+1] = promovido;
    filho[posicao+2]= Mfilho;
    numElementos++;
}

void pagina::imprimir(){
    cout << "[";
    for (int i = 0; i < numElementos; i++){
        cout <<"(" << chave[i] << ")";
    }
    cout << "]" << endl;
}
void pagina::depurar(){
    cout << "chaves: ";
    imprimir();
    cout << "posArquivo: ";
    for (int i = 0; i < numElementos+1; i++){
        cout << posArquivo[i] << " ";
    }
    cout<< endl;
}


