#include <iostream>
//#include "sequenceset.hpp"
#include "arvorebmais.hpp"

using namespace std;

int main() {
    arvorebmais mArvore;
    dado umDado;
    tipoChave umaChave;
    char operacao;
    do {
        try {
            cin >> operacao;
            switch (operacao) {
                case 'i': // inserir
                    cin >> umDado.tipo >> umDado.chave >> umDado.medida 
                    >> umDado.peso >> umDado.caloria;
                    mArvore.inserirDado(umDado);
                    break;
                case 'b': // buscar
                    cin >> umaChave;
                    umDado = mArvore.buscar(umaChave);
                    cout << "Busca: "<< umDado.chave << "/" << umDado.tipo << "/"
                    << umDado.chave << "/"<< umDado.medida << "/"<<umDado.peso 
                    << "/"<< umDado.caloria << endl;
                    break; 
                case 'p': // mostrar estrutura
                    mArvore.imprimir();
                    break; /*
                case 'd': // mostrar estrutura
                    meuSeqSet.depurar();
                    break; */
                case 's': // sair
                    // será tratado no while
                    break;
                default:
                    cout << "Opção inválida!" << endl;
            }
        } catch (runtime_error& e) {
            cerr << e.what() << endl;
        }
    } while (operacao != 's');

    return 0;
}